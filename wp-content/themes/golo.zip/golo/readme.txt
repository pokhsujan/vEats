Copyright
--------------
Golo City Guide WordPress Theme, Copyright 2020 Uxper.co

Golo is distributed under the terms of the GNU/GPL v2 or later


Install Steps
--------------
Step 1: Go to Appearance > Add New Themes, then click Upload button

Step 2: Go to browse, then select the golo.zip file

Step 3: Click "Install Now" to install Golo

Step 4: Activate the newly installed Golo by going to Appearance > Themes, find Golo and click on "Activate" button

Step 5: Once Golo is activated, you will be redirected to Golo Welcome Screen. Switch to Plugins tab to install plugins.

Step 6: click "Install" to begin installing plugins. After that, you will have to activate plugins.

Best regards!