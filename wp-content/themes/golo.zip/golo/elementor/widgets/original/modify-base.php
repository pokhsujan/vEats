<?php

namespace Golo_Elementor;

defined( 'ABSPATH' ) || exit;

abstract class Modify_Base {
}
