<?php

namespace MyStripe\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements ExceptionInterface
{
}
