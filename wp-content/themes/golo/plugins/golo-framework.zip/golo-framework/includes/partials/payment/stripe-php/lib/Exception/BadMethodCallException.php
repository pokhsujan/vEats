<?php

namespace MyStripe\Exception;

class BadMethodCallException extends \BadMethodCallException implements ExceptionInterface
{
}
