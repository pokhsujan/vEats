'use strict';
jQuery( document ).ready( function($) {

} );
